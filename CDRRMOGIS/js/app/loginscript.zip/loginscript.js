//request
  var request = {
    login: false
  };

//iframes
  var iframe = {
    login: document.getElementById('login_iframe')
  };

//forms
  var login_form = document.getElementById('login_form');

//fields
  //login_form fields
    var login_form_input = {
      username: document.getElementById('login_form_username_input'),
      password: document.getElementById('login_form_password_input'),
      submitbtn: '#login_form_submit_btn'
    };

canCloseModal = true;
//variable declaration end.......................................................

login_form.onsubmit = function(){

  if(hasSpace(login_form_input.username.value))
  {
    createmessage(3, 'That is an invalid <b>Username.</b>', true);
    return false;
  }
  if(isWhitespace(login_form_input.password.value))
  {
    createmessage(3, 'You entered a wrong <b>Password.</b>', true);
    return false;
  }
  request.login = true;
  $(login_form_input.submitbtn).button('loading');
  canCloseModal = false;
  return true;
};

iframe.login.onload = function()
{
  var server_message = iframe.login.contentDocument.body.innerHTML;
  if(request.login)
  {
    if(server_message == "admintype")
    {
      window.location = "adminpanel.php";
    }
    else if(server_message == "cswdtype")
    {
      window.location = "cswdpanel.php";
    }
    else if(server_message == "brgytype")
    {
      window.location = "brgypanel.php";
    }
    else if(server_message == "deactivated")
    {
      createmessage(3, 'Your account is currently deactivated', true);
    }
    else if(server_message == "error")
    {
      createmessage(3, 'Wrong Username or Password', true);
    }
    else
    {
      createmessage(3, '<b>Oh Snap!</b> There is a problem with the server or your connection.', true);
    }

    request.login = false;
    $(login_form_input.submitbtn).button('reset');
    canCloseModal = true;
    iframe.login.src = "";
  }
};

$('#myModal').on('hide.bs.modal', function (e) {
  return canCloseModal;
});